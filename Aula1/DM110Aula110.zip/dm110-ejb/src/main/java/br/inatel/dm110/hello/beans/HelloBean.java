package br.inatel.dm110.hello.beans;


public class HelloBean {

}

